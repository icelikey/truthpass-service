# 真验 Zhenyan：鱼油批次公共信誉 Demo

> 项目文档版本：v1.4.0
> 最近修改：2026-10-15
> 本次修改：完成队友 Agent/CLI/CFI 公共协议兼容合并，统一 Vercel API、真实钱包交易和旧观察台入口。

真验（TruthPass）是一层面向消费者 Agent 的服务可靠性与公共信誉基础设施。鱼油只是演示品类，核心范式是：消费者 Agent 通过 CLI 调用真验，生产方、检测 Agent 和冷链 Agent 围绕同一个批次提交可验证证据，由确定性验收器完成判断，再把任务级履约结果和证据哈希沉淀为公共信誉。

当前首页同时展示 CLI 参考实现：`/api/cli/reference/manifest` 暴露商品、批次、验证、售后和订单准备能力。Demo 数据明确标记为 `demo/synthetic`；订单准备返回 `prepared_pending_checkout`，只有商家 Checkout Adapter、真实支付回调和钱包 receipt 完成后才进入真实交易状态。

## 解决的问题

消费者看到“高浓度鱼油”“深海原料”“无腥味”等宣传时，很难同时确认：标签含量是否兑现、鱼油是否氧化、冷链是否中断、报告是否对应当前批次、检测服务此刻是否可用。链上身份和历史评分也不能自动证明服务当前可用或数据真实。

真验把问题拆成四步：

1. **发现**：根据鱼油批次任务寻找检测和冷链服务；
2. **探测**：检查端点在线、能力匹配、返回格式和签名；
3. **验收**：用规则核对批次、时间、EPA+DHA、过氧化值、TOTOX、冷链和签名；
4. **沉淀**：记录服务履约反馈，消费者购买后提交经过授权的体验反馈，供后续 Agent 查询。

## Demo 闭环

```text
消费者 Agent 通过 CLI 查询 FO-2026-001
        ↓
真验发现三个实验室服务
        ↓
lab-a：在线但批次错、签名无效、指标不达标
lab-b：当前离线
lab-c：在线、签名有效、指标和冷链通过
        ↓
确定性 Verifier 选择 lab-c
        ↓
生成证据卡和任务履约反馈
        ↓
消费者授权 Agent 登记购买并提交“包装/气味/批次可查”反馈
        ↓
反馈哈希和贡献事件可锚定到 BOT Chain
```

演示数据全部标记为 `demo/synthetic`，不能作为真实供应链证明。链上保存身份、任务哈希、结果和证据哈希；报告全文、图片、传感器明细和个人信息留在链下。

比赛网页只是现场观察台，不是产品主入口。用户自有 Agent 或我们提供的消费者 Agent 安装 CLI 后，可以查询、解释、推荐和准备下单；Python 宿主示例见 [examples/truthpass_consumer_agent_v1.py](examples/truthpass_consumer_agent_v1.py)，完整交付边界见 [docs/release-v0.9.0-consumer-agent-mainnet.md](docs/release-v0.9.0-consumer-agent-mainnet.md)、[docs/integration-v1.2.0.md](docs/integration-v1.2.0.md)、[docs/integration-v1.2.1-wallet-discovery.md](docs/integration-v1.2.1-wallet-discovery.md)、[docs/truthpass-consumer-agent-v1.2.2.md](docs/truthpass-consumer-agent-v1.2.2.md) 和 [docs/integration-v1.4.1-deployment-fix.md](docs/integration-v1.4.1-deployment-fix.md)。根路径 `/` 使用新的 React 前端，旧观察台保留在 `/web-demo` 作为回滚入口（`/web-demo/` 尾斜杠同样支持）。

## 交互状态标记

所有页面、CLI 和 API 都必须区分以下状态，不能把演示回放当作用户真实交易：

| 标记 | 含义 |
| --- | --- |
| `demo/synthetic` | 仓库内置的模拟批次、模拟传感器或历史回放数据 |
| `wallet_signed` | 用户钱包已签名交易请求，尚未确认广播结果 |
| `wallet_broadcast` | 用户钱包已广播，已取得交易 Hash，等待 receipt |
| `mainnet_receipt_verified` | BOT Chain 主网 receipt、目标合约和业务事件全部匹配 |

消费者 `purchase` 和 `contribution` 发送到 Consumer Gateway，经济性质疑 `openChallenge` 发送到 Audit Escrow 并携带真实质押。没有钱包插件、用户拒签、交易回滚或事件缺失时，前端只能显示待验证/失败，不能生成演示 Hash。

## 质量规则示例

当前演示任务使用以下验收条件：

| 指标 | 示例门槛 |
| --- | ---: |
| EPA+DHA 总含量 | ≥ 70% |
| 过氧化值 | ≤ 5 |
| TOTOX | ≤ 20 |
| 冷链中断 | ≤ 6 小时 |
| 报告批次 | 必须等于商品批次 |
| 检测签名 | 必须有效 |

大模型只负责把自然语言采购意图拆成任务和解释结果；通过、拒绝、评分和防重复由代码规则决定。

## 运行

```bash
npm install
npm run demo
npm test
npm run typecheck
npm run truthpass -- replay --batch FO-2026-001 --json
npm run truthpass -- verify --batch FO-2026-001 --json
npm run truthpass -- recommend --batch FO-2026-001 --json
npm run truthpass -- inspect --batch FO-2026-001 --json
npm run truthpass -- FO-2026-001 --json
npm run truthpass -- explain FO-2026-001
npm run truthpass -- order --batch FO-2026-001 --json
npm run web:server
```

## 目录

```text
src/types.ts                       通用任务、证据和服务类型
src/evidence.ts                    EvidenceEnvelope、规范化哈希和 Ed25519 验签
src/jev/model.ts                   JEV 输入输出合同
src/jev/context.ts                 JEV 安全决策门和确定性降级
src/verifier.ts                    确定性鱼油验收规则
src/registry.ts                    服务探测、排序和履约反馈
src/consumer.ts                    消费者授权、购买登记和反馈防刷
src/replay.ts                      验证到消费者贡献的本地完整回放
src/local-ledger.ts                可校验的本地追加账本（不是区块链替代品）
src/chain.ts                       BOT Chain RPC、ABI、receipt 和事件校验
src/rpc-fetch.ts                   Node RPC 代理适配（本机显式 TRUTHPASS_HTTPS_PROXY）
src/web-server.ts                  网页观察台 BFF 和主网状态回读
contracts/TruthPassConsumerGateway.sol 消费者无特权钱包入口
contracts/TruthPassAuditEscrow.sol     Agent 审计质押、奖励和扣款
src/demo.ts                        鱼油端到端演示
contracts/TruthPassEvidenceAnchor.sol 证据、验收、购买、贡献、争议和撤销合约
examples/fish-oil-batch-task.json  鱼油任务样例
test/                              验收和消费者参与测试
docs/fish-oil-development-plan.md  完整开发方案和分工
docs/architecture-v0.3-fish-oil.md 鱼油战略架构
docs/consumer-participation.md     消费者 Agent 参与规则
docs/fish-oil-demo-script.md       现场演示脚本
docs/frontend-visual-plan.md       前端页面和美工预案
docs/strategy-v0.4-consumer-cli.md 消费者 CLI、链上结构、商业与展示战略
docs/cli-contract.md               CLI 命令、JSON 输出和安全合同
docs/DOCUMENT-VERSIONING.md        文档版本、修改说明和协作规则
docs/jev-integration-v0.5.md       JEV 结构化决策门、类型合同和降级策略
docs/target-development-v0.8.0.md 完整目标、完成标准和部署门禁
docs/implementation-v0.8.0.md      本地完整回放和链上状态合同
docs/configuration-v0.8.1.md       Bohr Testnet 配置和部署回填说明
config/bot-chain-testnet.example.json 测试网公开配置模板
config/bot-chain-testnet.deployed.json 真实测试网地址、角色和生命周期 receipt
docs/chain-composition-v0.8.3.md 生产链下数据、Agent 与 BOT Chain 公共锚定层组合
docs/deployment-v0.8.2.md         部署脚本、Faucet 和部署交接记录
docs/private-chain-blueprint-v0.8.4.md BOT Chain 运作逻辑、私链职责、联盟链节点和公共检查点方案
docs/architecture-production-v1.0.0.md 企业部署、传感器/服务器取证、第三方认证和 BOT Chain 上链协议
docs/wallet-interaction-v1.0.1.md 浏览器钱包、主网 calldata、receipt 回读和 Agent manifest
docs/consumer-wallet-audit-v1.1.0.md 消费者 Gateway、事件验收和 Agent 审计质押
docs/future-vision-v0.8.5.md 可信商品平台愿景、白牌/新生商家品牌成长和跨品类扩展
docs/release-v0.9.0-consumer-agent-mainnet.md 消费者 Agent、CLI、主网 receipt 和订单适配边界
docs/integration-v1.2.0.md 队友代码兼容合并、React/Vercel/API、钱包和 Agent 审计验收
examples/consumer-agent-cli.mjs 用户 Agent 通过 child_process 调用 CLI 的最小示例
examples/truthpass_consumer_agent_v1.py 用户 Agent 查询批次、读取 JEV/链状态并准备钱包交易
docs/truthpass-consumer-agent-v1.2.2.md CoinCall 对照的 TruthPass Consumer Agent 接入说明
config/bot-chain-mainnet.replay.json 主网业务回放公开 receipt manifest
assets/fish-oil-evidence-dashboard.png 前端高保真方向图
assets/fish-oil-consumer-cli-journey.png 消费者 CLI 证据故事方向图
```

## 赛题对应

项目对应赛题一“Agent 公共信誉与服务验收”：

- 服务探测：`ServiceRegistry.evaluate`；
- 交付验收：`verifyExecution`；
- 履约记录：`FeedbackRecord`；
- 消费者参与：`ConsumerParticipationRegistry`；
- 链上锚定：`TruthPassEvidenceAnchor.sol` 和 `src/chain.ts`；BOT Chain 主网部署与业务 receipt 见 [`config/bot-chain-mainnet.deployed.json`](config/bot-chain-mainnet.deployed.json)、[`config/bot-chain-mainnet.gateway.json`](config/bot-chain-mainnet.gateway.json) 和 [`config/bot-chain-mainnet.audit-escrow.json`](config/bot-chain-mainnet.audit-escrow.json)；
- 抗刷分基础：反馈绑定购买记录、任务哈希、服务身份和证据哈希。

ERC-8004 作为身份、信誉和验证模型的参考；当前仓库已在 BOT Chain 主网完成 Anchor、Consumer Gateway、Audit Escrow 部署和角色回读，并保留 `evidence → verification → purchase → contribution` 的 `demo/synthetic` 业务回放。仍待用非部署钱包完成现场 `purchase → contribution → dispute` 交易，并接入真实产线、实验室和设备签名。

JEV 只用于结构化判别、缺口识别和服务路由；最终通过/拒绝仍由确定性 `Verifier` 决定。接入边界、失败关闭和回放要求见 [docs/jev-integration-v0.5.md](docs/jev-integration-v0.5.md)。
